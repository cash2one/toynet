/**
* Copyright (c) 
*
* @author 
*/
// EventRepository.cpp
#include "stdafx.h"
#include <skynet/detail/EventRepository.h>
#include <skynet/Event.h>
#include <skynet/Message.h>
#include <skynet/detail/Assert.h>

namespace skynet
{

EventRepository::~EventRepository()
{
    for (Events::iterator pos = events_.begin(); pos != events_.end(); ++pos) {
        delete (*pos).second;
        pos = events_.erase(pos);
    }
}

void EventRepository::subscribe(Event* event)
{
    WN_ASSERT(event != 0);
    WN_ASSERT(events_.find(event->getMessageType()) == events_.end());
    events_.insert(Events::value_type(event->getMessageType(), event));
}


void EventRepository::unsubscribe(key_t key)
{
    Events::iterator pos = events_.find(key);
    if (pos != events_.end()) {
        delete (*pos).second;
        events_.erase(pos);
    }
}


bool EventRepository::publish(const Message& msg, const void* arg/* = 0*/)
{
    Events::const_iterator pos = events_.find(msg.getMessageType());
    WN_ASSERT((pos != events_.end()) && "�̺�Ʈ ����ҿ� ���� �̺�Ʈ");
    if (pos != events_.end()) {
        return (*pos).second->call(msg, arg);
    }
    return false;
}

} // namespace skynet
