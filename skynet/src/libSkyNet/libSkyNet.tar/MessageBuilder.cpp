/**
* Copyright (c) 
*
* @author 
*/
// MessageBuilder.cpp
#include "stdafx.h"
#pragma warning( push)
#pragma warning( disable : 4702)
#include <skynet/detail/MessageBuilder.h>
#pragma warning( pop)
#include <skynet/Message.h>
#include <ace/Message_Block.h>
#include <memory>
#include <skynet/detail/Assert.h>

namespace skynet
{

// = MessageBuilderRepository

MessageBuilderRepository::~MessageBuilderRepository()
{
    for (BuilderMap::const_iterator pos = repository_.begin();
            pos != repository_.end(); ++pos) {
        delete (*pos).second;
    }
}


void MessageBuilderRepository::add(MessageBuilder* builder)
{
    WN_ASSERT(builder != 0);
    WN_ASSERT(repository_.find(builder->getMessageType()) == repository_.end());
    repository_.insert(
        BuilderMap::value_type(builder->getMessageType(), builder));
}


Message* MessageBuilderRepository::build(ACE_Message_Block& block,
    MessageAdaptor& adaptor) const
{
    MessageType mt = extractMessageType(block);
    BuilderMap::const_iterator pos = repository_.find(mt);
    if (pos == repository_.end())
        return 0;

    MessageBuilder* builder = pos->second;
    WN_ASSERT(builder != 0);
    std::auto_ptr<Message> msg(builder->create());
    WN_ASSERT(msg.get() != 0);
    if (! msg->serializeFrom(block, adaptor))
        return 0;
    return msg.release();
}

} // namespace skynet
